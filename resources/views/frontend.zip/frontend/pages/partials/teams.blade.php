<section class="team section" id="team">
    <div class="container">
        <div class="row">
            <div class="col-12 wow zoomIn">
                <div class="section-title">
                    <h2 style="color: red;">Meet With Our <span>Faculty</span></h2>
                    <hr style="color: red; height:5px;">
                    <p style="text-align: center;">"A Teacher is a compass that activates the magnets of curiosity,
                        knowledge, ans wisdom."</p>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="client-slider owl-carousel owl-theme">
                <div class="single-team">
                    <img src="{{Vite::asset('resources/images/man2.jpg')}}" alt="#" class="img=thumbnail">
                    <div class="team-hover">
                        <h4>
                            Mr. Vikash Singh
                            <span>Principal</span>
                            <span>-</span>
                        </h4>
                    </div>
                </div>

                <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
                <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              <div class="single-team">
                  <img src="{{Vite::asset('resources/images/man1.jpg')}}" alt="#" class="img=thumbnail">
                  <div class="team-hover">
                      <h4>
                          Harvirendra Singh
                          <span>Admin</span>
                          <span>-</span>
                      </h4>
                  </div>
              </div>
              

                
                <div class="button">
                    <a href="#" class="btn text-center float-end">View More <i
                            class="fas fa-long-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
