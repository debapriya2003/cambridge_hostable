   <section class="our-features section">
       <div class="container">
           <h2 style="color: red ; text-align: center;">Facilities</h2>
           <hr style="color: red; height:5px">
           <div class="row">
               <div class="col-lg-4 col-md-4 col-12 wow fadeInUp" data-wow-delay="0.4s"
                   style="visibility: visible; animation-delay:0.4s; animation-name:fadeInUp;">
                   <div class="single-feature">
                       <div class="feature-head">
                           <img src="{{Vite::asset('resources/images/th.jpg')}}" alt="#" class="w-25">
                       </div>
                       <h2 class="text-dark">Science Lab</h2>
                       <p class="text-dark">
                           Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias iste illum distinctio
                           impedit quas est, tempora voluptates, pariatur hic assumenda exercitationem a deleniti.
                           Explicabo minus perferendis delectus, debitis odio mollitia.

                       </p>
                   </div>
               </div>
               <div class="col-lg-4 col-md-4 col-12 wow fadeInUp" data-wow-delay="0.4s"
                   style="visibility: visible; animation-delay:0.4s; animation-name:fadeInUp;">
                   <div class="single-feature">
                       <div class="feature-head">
                           <img src="{{Vite::asset('resources/images/download.jpg')}}" alt="#" class="w-25">
                       </div>
                       <h2 class="text-dark">Computer Lab</h2>
                       <p class="text-dark">
                           Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias iste illum distinctio
                           impedit quas est, tempora voluptates, pariatur hic assumenda exercitationem a deleniti.
                           Explicabo minus perferendis delectus, debitis odio mollitia.

                       </p>
                   </div>
               </div>
               <div class="col-lg-4 col-md-4 col-12 wow fadeInUp" data-wow-delay="0.4s"
                   style="visibility: visible; animation-delay:0.4s; animation-name:fadeInUp;">
                   <div class="single-feature">
                       <div class="feature-head">
                           <img src="{{Vite::asset('resources/images/comp.jpg')}}" alt="#" class="w-25">
                       </div>
                       <h2 class="text-dark">Sports</h2>
                       <p class="text-dark">
                           Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias iste illum distinctio
                           impedit quas est, tempora voluptates, pariatur hic assumenda exercitationem a deleniti.
                           Explicabo minus perferendis delectus, debitis odio mollitia.

                       </p>
                   </div>
               </div>
           </div>
       </div>
   </section>

   <div >made by ishisoft pvt ltd</div>
