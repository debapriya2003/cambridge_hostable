<div class="topbar">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-12">
                <ul class="content">
                    <li><i class="fas fa-phone"></i> 9954144972 </li>
                    <li><a href="#"><i class="fas fa-envelope"></i><span
                                class="text-white"> cambridgehighschoolpanchgram01@gmail.com</span></a></li>
                    <li><i class="fas fa-clock"></i>Office Hours: Monday to Saturday, 8:30 AM to 10:30 AM</li>
                </ul>
            </div>
        </div>
    </div>
</div>