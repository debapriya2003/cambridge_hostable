 <div class="header-menu">
     <div class="container">
         <div class="row">
             <div class="col-12">
                 <nav class="navbar navbar-default">
                     <div class="navbar-collapse">
                         <ul id="nav" class="nav menu navbar-nav">
                             <li class="active"><a href="/">Home</a></li>
                             <li><a href="{{route('frontend.vision_mission')}}">Vision & Mission</a></li>    
                             <li><a href="{{route('frontend.admission_procedure')}}">Prospectus</a></li>
                             <li><a href="{{route('frontend.gallery_photos')}}">Photo Gallery</a></li>
                             <li><a href="{{route('frontend.contact_us')}}">Contact Us</a></li>
                         </ul>
                     </div>
                 </nav>
             </div>
         </div>
     </div>
 </div>
